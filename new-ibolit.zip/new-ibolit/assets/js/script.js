$('.moreless-button').click(function() {
    $('.moretext').slideToggle();
    if ($('.moreless-button').text() == "Развернуть") {
        $(this).text("Повернуть");
        $('.more-less-arrow').addClass('rotate')
    } else {
        $(this).text("Развернуть");
        $('.more-less-arrow').removeClass('rotate')
    }
});

$('.tab').on('click', function(evt) {
    evt.preventDefault();
    $(this).addClass('active');
    var sel = this.getAttribute('data-toggle-target');
    $('.tab-content').removeClass('active').filter(sel).addClass('active');
});
$(".drop-down-content").slideUp();


$('.banner-slider').slick({
    dots:true,
    prevArrow:"<img class='a-left control-c prev slick-prev' src='./assets/img/arrow-left.png'>",
    nextArrow:"<img class='a-right control-c next slick-next' src='./assets/img/arrow-right.png'>"
});

$('.slider').slick({
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    dots:false,
    prevArrow:"<div class='slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow:"<div class='slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>",
    responsive: [
        {
            breakpoint: 1024,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 3,
                infinite: true,
                dots: true
            }
        },
        {
            breakpoint: 600,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 2
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1
            }
        }
        // You can unslick at a given breakpoint now by adding:
        // settings: "unslick"
        // instead of a settings object
    ]
});

$('.slider-acc').slick({
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    dots:false,
    prevArrow:"<div class='slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow:"<div class='slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>"
});
$('.brand-slider').slick({
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    dots:false,
    prevArrow:"<div class='slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow:"<div class='slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>"
});


$('.accesories-slider-container').slick({
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 3,
    dots:false,
    prevArrow:"<div class='slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow:"<div class='slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>"
});


$('.single-blog-slider').slick({
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    dots:true,
    prevArrow:"<div class='slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow:"<div class='slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>"
});


$('.fix-category-slider').slick({
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    dots:false,
    prevArrow:"<div class='slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow:"<div class='slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>"
});

//filtrations
$(".dropdown-toggle").click(function () {
    $(this).next(".drop-down-content").slideToggle();
});
//filtrations

$(".slider-tabs").slick({
    infinite: true,
    slidesToShow: 5,
    slidesToScroll: 1,
    dots:false,
    prevArrow: "<div class='slick-left-arrow-bug slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow: "<div class='slick-right-arrow-bug slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>",
});
$(".slider-bug").slick({
    infinite: true,
    slidesToShow: 6,
    slidesToScroll: 1,
    dots:false,
    prevArrow: "<div class='slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow: "<div class='slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>",
});

$('.slider-for').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    fade: true,
    dots:false,
    asNavFor: '.slider-nav'
});
$('.slider-nav').slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    asNavFor: '.slider-for',
    centerMode: true,
    focusOnSelect: true,
    arrows:false,
});


$('.fav-prod-slider').slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    dots:true,
    arrows:false,
    prevArrow:"<div class='slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow:"<div class='slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>"
});


$('.slider-audio').slick({
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    dots:false,
    prevArrow:"<div class='slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow:"<div class='slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>",
});


//mobile-menu slider

$('.menu-slider').slick({
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    dots:false,
    arrows:false,
});

function openTab(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}



let curr_lang = document.querySelector('.current-lang');
let choose_lang = document.querySelector('.choose-lang');

curr_lang.addEventListener('click',()=> {
    this.classList.add('rotate-img');
})



$(document).ready(()=> {
    $('.current-lang').click(()=> {
        $('.choose-lang').slideToggle()
    })
})

const tabsbtn = document.querySelectorAll(".tabs_nav_btn");
const tabsItems = document.querySelectorAll(".tabs_item")

tabsbtn.forEach( function(item) {
    item.addEventListener("click",function() {
        let currentBtn = item;
        let tabId = currentBtn.getAttribute("data-tab");
        let currentTab = document.querySelector(tabId);


        tabsbtn.forEach(function(item) {
            item.classList.remove("active")
        });
        tabsItems.forEach(function(item) {
            item.classList.remove("active");
        })
        currentBtn.classList.add("active");
        currentTab.classList.add("active")
    })
});

const btns_receive = document.querySelectorAll(".btn_how_to_receive");
const tabs_receive = document.querySelectorAll(".content_how_to_receive")

btns_receive.forEach( function(item) {
    item.addEventListener("click",function() {
        let currentBtn = item;
        let tabId = currentBtn.getAttribute("data-tab");
        let currentTab = document.querySelector(tabId);


        btns_receive.forEach(function(item) {
            item.classList.remove("active")
        });
        tabs_receive.forEach(function(item) {
            item.classList.remove("active");
        })
        currentBtn.classList.add("active");
        currentTab.classList.add("active")
    })
});

const btns_payment_method  = document.querySelectorAll(".btn_payment_method");
const contents_payment_method = document.querySelectorAll(".content_payment_method")

btns_payment_method .forEach( function(item) {
    item.addEventListener("click",function() {
        let currentBtn = item;
        let tabId = currentBtn.getAttribute("data-tab");
        let currentTab = document.querySelector(tabId);


        btns_payment_method .forEach(function(item) {
            item.classList.remove("active")
        });
        contents_payment_method.forEach(function(item) {
            item.classList.remove("active");
        })
        currentBtn.classList.add("active");
        currentTab.classList.add("active")
    })
});

const loan_terms = document.querySelectorAll(".loan_term");
loan_terms.forEach( (item) =>  {
    item.addEventListener("click",  function () {
        loan_terms.forEach((item) => {
            item.classList.remove("active")
        })
        item.classList.add("active");
    });
})

const Show_all_cast = document.querySelector(".Show_all_cast");
const continuation_context = document.getElementById("continuation_context");

function toggle_show() {
    continuation_context.classList.toggle("toggle")
}

// comparisons
let acc = document.getElementsByClassName("accordion");
let i;
for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function () {
        this.classList.toggle("active");
        let panel = this.nextElementSibling;
        if (panel.style.maxHeight) {
            panel.style.maxHeight = null;
        } else {
            panel.style.maxHeight = panel.scrollHeight + "px";
        }
    });
}

//basket
$(".slider-tabs").slick({
    infinite: true,
    slidesToShow: 5,
    slidesToScroll: 1,
    dots:false,
    prevArrow: "<div class='slick-left-arrow-bug slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow: "<div class='slick-right-arrow-bug slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>",
});
$(".slider-bug").slick({
    infinite: true,
    slidesToShow: 6,
    slidesToScroll: 1,
    dots:false,
    prevArrow: "<div class='slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow: "<div class='slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>",
});


$('.catalog-open').click(()=> {
   $('.catalog-close').css('display','block');
   $('.catalog-open').css('display','none');
   $('.catalog-overlay').css('display','block')
})
$('.catalog-close').click(()=> {
    $('.catalog-close').css('display','none');
    $('.catalog-open').css('display','block');
    $('.catalog-overlay').css('display','none')
})






const appleMemories = document.querySelectorAll(".card");

appleMemories.forEach(memory => {
    memory.addEventListener("click", (e) => {
        if(memory.classList.contains("not-available")) return;

        const memoryDisplay = document.getElementById("memory");
        memoryDisplay.innerText = e.target.innerText;

        appleMemories.forEach(memory => memory.classList.remove("active"));
        memory.classList.add("active");
    });
});

// adding and removing active class to tabs and corresponding contents

const accessoryContent = document.querySelector(".accessories-content");
const serviceContent = document.querySelector(".services-content");
const characteristicContent = document.querySelector(".characts-content");
const descriptionContent = document.querySelector(".description");
const productMenuBtns = document.querySelectorAll(".menu-button");

productMenuBtns.forEach(btn => {
    btn.addEventListener("click", () => {
        removeActive();

        btn.classList.add("active");

        const activeTab = document.querySelector(".menu-button.active");

        switch (activeTab.innerText) {
            case "Аксессуары":
                accessoryContent.classList.add("active");
                break;
            case "Услуги":
                serviceContent.classList.add("active");
                break;
            case "Характеристики":
                characteristicContent.classList.add("active");
                break;
            case "Описание":
                descriptionContent.classList.add("active");
                break;

            default:
                ""
        }
    });
});

const removeActive = () => {
    productMenuBtns.forEach(btn => btn.classList.remove("active"));
    accessoryContent.classList.remove("active");
    serviceContent.classList.remove("active");
    characteristicContent.classList.remove("active");
    descriptionContent.classList.remove("active");
};


//repair service slider
$('.testimonial-slider').slick({
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    dots: false,
    prevArrow:"<div class='slick-left-arrow'><img class='a-left control-c arrow prev slick-prev' src='../../assets/img/arrow.png'></div>",
    nextArrow:"<div class='slick-right-arrow'><img class='a-right control-c arrow next slick-next' src='../../assets/img/arrow.png''></div>"
});

$(".cols").click(function () {
    $(".tab-content-2").css("display", "none");
    $(".tab-content-1").css("display", "flex");
    $(".cols").addClass("active-filter-tab");
    $(".rows").removeClass("active-filter-tab");
});
$(".rows").click(function () {
    $(".tab-content-1").css("display", "none");
    $(".tab-content-2").css("display", "block");
    $(".rows").addClass("active-filter-tab");
    $(".cols").removeClass("active-filter-tab");
});
$('.horizontal-prod-slider').slick({
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 3,
    arrow:false,
    dots:true
})


//search icon header
$('.search-products').click(function () {
    $('.search-popup').toggle();
})


$(document).scroll(function() {
    var y = $(this).scrollTop();
    if (y > 200) {
        $('.widget').addClass('show-div');
    } else {
        $('.widget').removeClass('show-div');
    }
});
$(".widget .scroll-top").click(function () {
    $("html").scrollTop(0);
});

$('#phone-widget').click(function (){
    $('.widget-remont-element').css("right","0")
})
$('.close-elm').click(function (){
    $('.widget-remont-element').css("right","-1000px");
})